import math
from django.http.response import HttpResponse
from django.test import TestCase

import operator

# Create your tests here.
from django.test.client import Client


class TestErrorHandling(TestCase):

  def test_ok_request(self):
    c = Client()
    response = c.post("/calculate", data = {
      "x":10, "y":15, "operation":"+"
    })
    assert isinstance(response, HttpResponse)
    self.assertEqual(response.status_code, 200, "Odpowiedż na poprawnie wypełniony formularz powinna mieć status 200 ")
    self.assertIn('25', response.content.decode(response.charset), "Poprawną odpowiedzią na to pytanie jest 25")

  def test_errorneous_requests(self):
    values = [{}, {"x":5}, {"y":5}, {'op':'+'}, {'x':5, 'op':'+'}] # Not all values
    values += [
      {'x':5, 'y':'10', 'op': 'kotek!'},
      {'x':5, 'y':'kotek', 'op': '*'},
      {'x':'kotek', 'y':'18', 'op': '*'}
    ]
    c = Client()
    for v in values:
      with self.subTest(v):
        response = c.post("/calculate", data = v)
        assert isinstance(response, HttpResponse)
        self.assertEqual(response.status_code, 200, "Odpowiedż na źle wypełniony formularz powinna mieć status 200 ")
        self.assertIn('Zła wartość parametru', response.content.decode(response.charset), "Odpowiedź na źle wypełniony formularz powinna zawierać ciąg znaków")

  def test_mathematics(self):
    c = Client()
    for op, func in (
        ('+', operator.add), ('-', operator.sub), ('*', operator.mul),
        ('/', operator.truediv), ('//', operator.floordiv)):
      for x in range(0, 100, 3):
        for y in range(1, 20):
          with self.subTest((op, func, x, y)):
            result = int(math.floor(func(x, y)))
            response = c.post("/calculate", data = {
              "x":x, "y":y, "operation":op
            })
            assert isinstance(response, HttpResponse)
            self.assertEqual(response.status_code, 200, "Odpowiedż na poprawnie wypełniony formularz powinna mieć status 200 ")
            self.assertIn(str(result), response.content.decode(response.charset), "Niepoprawny wynik obliczeń")

  def test_invalid_methods(self):
    for method in ['PUT', 'OPTIONS', 'DELETE', "__KOTEK__"]:
      c = Client()
      response = c.generic(method, "/calculate", data={})
      self.assertEqual(response.status_code, 405, "Niepoprawna metoda powinna spowodować zwrócenie odpowiedzi o statusie 405")