# -*- coding: utf-8 -*-

from .rec_a import RecA

def function(a):
    assert isinstance(a, RecA)