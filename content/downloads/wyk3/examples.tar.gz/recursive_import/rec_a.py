# -*- coding: utf-8 -*-

from . import rec_b

class RecA:
    def __init__(self):
        rec_b.function(self)