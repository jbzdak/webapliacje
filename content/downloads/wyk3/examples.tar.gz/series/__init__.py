# -*- coding: utf-8 -*-

from .fibonacci import Fibonacci
from .primes import Primes