from django.http import HttpResponse
from django.shortcuts import render


ASK_TEMPLATE= """
  <!DOCTYPE html>
  <html xmlns="http://www.w3.org/1999/html">
  <head>
      <meta charset="utf-8">
  </head>
  <body>

    <h1>{}<h1>
    <form action="/calculate" method="POST">
      <input name="x">
      <input name="operation">
      <input name="y">

      <button> Submit</button>
    </form>
  </body>
  </html>
"""

# def get_form(request):
#   if request.method != 'GET': # Jeśli zapytanie nie używa GET
#     return HttpResponse(status=405) # Zwracamy błąd użycia niedozwolonej metody
#   return HttpResponse(content=ASK_TEMPLATE)

def calculate(request):
  if request.method == 'POST':
      try:
          x1 = float(request.POST['x'])
          y1 = float(request.POST['y'])
          if request.POST['operation']=='+':
              res=x1+y1
          elif request.POST['operation']=='-':
              res=x1-y1
          elif request.POST['operation']=='*':
              res=x1*y1
          elif request.POST['operation']=='/' and y1!=0:
              res=x1/y1
          elif request.POST['operation']=='//' and y1!=0:
              res=x1//y1
          else:
              raise Exception("Zła wartość parametru!")
      except ValueError:
           return HttpResponse(status=200, content=ASK_TEMPLATE.format("Zła wartość parametru!"))
      except Exception:
          return HttpResponse(status=200, content=ASK_TEMPLATE.format("Zła wartość parametru!"))
      return HttpResponse(status=200, content="Result of {}{}{} is {}".format(request.POST['x'],request.POST['operation'],request.POST['y'],res))
  elif request.method == 'GET':
      return HttpResponse(status=200, content=ASK_TEMPLATE.format("Podaj dane:"))
  else:
      return HttpResponse(status=405)